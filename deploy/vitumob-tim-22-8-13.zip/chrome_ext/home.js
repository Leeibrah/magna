document.getElementById('main').removeChild(document.getElementById('download'))
