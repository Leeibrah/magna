<?php

class Order_total extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'order_id' => 'required',
		// 'sub_total' => 'required',
		// 'custom_import' => 'required',
		// 'shipping' => 'required',
		// 'vat' => 'required',
		// 'total' => 'required',
		// 'notes' => 'required'
	);
}