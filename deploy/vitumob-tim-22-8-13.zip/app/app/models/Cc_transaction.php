<?php

class Cc_transaction extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'order_id' => 'required',
		// 'provider' => 'required',
		// 'number' => 'required',
		// 'ccv' => 'required',
		// 'name' => 'required',
		// 'expiry_date' => 'required',
		// 'amount' => 'required',
		// 'notes' => 'required'
	);
}