<?php

class Item extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'session_id' => 'required',
		// 'ip_address' => 'required',
		// 'merchant_id' => 'required',
		// 'item_id' => 'required',
		// 'name' => 'required',
		// 'quantity' => 'required',
		// 'link' => 'required',
		// 'image' => 'required',
		// 'designer' => 'required',
		// 'color' => 'required',
		// 'size' => 'required',
		// 'package' => 'required',
		// 'print_on_demand' => 'required',
		// 'front_logo' => 'required',
		// 'custom_back_number' => 'required',
		// 'custom_back_name' => 'required',
		// 'price_usd' => 'required',
		// 'price_ksh' => 'required',
		// 'status' => 'required',
		// 'notes' => 'required'
	);
}