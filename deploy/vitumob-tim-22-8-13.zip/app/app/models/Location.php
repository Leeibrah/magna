<?php

class Location extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'country' => 'required',
		// 'city' => 'required',
		// 'neighbourhood' => 'required',
		// 'agents' => 'required',
		// 'contacts' => 'required',
		// 'notes' => 'required'
	);
}