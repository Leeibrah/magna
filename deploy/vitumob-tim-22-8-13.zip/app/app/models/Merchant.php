<?php

class Merchant extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'name' => 'required',
		// 'url' => 'required',
		// 'about' => 'required',
		// 'logo' => 'required',
		// 'orders_count' => 'required',
		// 'orders_worth' => 'required',
		// 'notes' => 'required'
	);
}