<?php

class Mpesa_transaction extends Eloquent {
	protected $guarded = array();

	public static $rules = array(
		// 'order_id' => 'required',
		// 'ipn_id' => 'required',
		// 'ipn_orig' => 'required',
		// 'ipn_dest' => 'required',
		// 'ipn_tstamp' => 'required',
		// 'ipn_text' => 'required',
		// 'ipn_user' => 'required',
		// 'ipn_pass' => 'required',
		// 'mpesa_code' => 'required',
		// 'mpesa_acc' => 'required',
		// 'mpesa_msisdn' => 'required',
		// 'mpesa_trx_date' => 'required',
		// 'mpesa_trx_time' => 'required',
		// 'mpesa_amt' => 'required',
		// 'mpesa_sender' => 'required',
		// 'notes' => 'required'
	);
}