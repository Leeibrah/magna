<?php

class Mpesa_transactionsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('mpesa_transactions')->truncate();

		$mpesa_transactions = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('mpesa_transactions')->insert($mpesa_transactions);
	}

}
