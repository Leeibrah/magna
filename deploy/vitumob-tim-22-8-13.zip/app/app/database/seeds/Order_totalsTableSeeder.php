<?php

class Order_totalsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('order_totals')->truncate();

		$order_totals = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('order_totals')->insert($order_totals);
	}

}
