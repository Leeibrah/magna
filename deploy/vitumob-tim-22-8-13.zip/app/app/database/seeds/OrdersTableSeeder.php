<?php

class OrdersTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('orders')->truncate();

		$orders = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('orders')->insert($orders);
	}

}
