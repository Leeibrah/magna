<?php

class Cc_transactionsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('cc_transactions')->truncate();

		$cc_transactions = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('cc_transactions')->insert($cc_transactions);
	}

}
