<div id='footer'>
    <span>&copy;2013 VituMob</span>
    <span><a href='{{ Functions::host() }}/faq'>FAQ</a></span>
    <span><a href='{{ Functions::host() }}/privacy'>privacy</a></span>
    <span><a href='{{ Functions::host() }}/returns'>returns</a></span>
</div>
