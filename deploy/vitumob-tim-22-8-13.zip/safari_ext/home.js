if (window.top === window && document.location.hostname == "www.vitumob.com" && document.location.pathname == "/beta") document.getElementById('main').removeChild(document.getElementById('download'))
